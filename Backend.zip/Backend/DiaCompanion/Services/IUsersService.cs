using Microsoft.AspNetCore.Mvc;
using DiaCompanion.Api.Common;
using DiaCompanion.Api.Dtos;
using DiaCompanion.Api.Entities;

namespace DiaCompanion.Api.Services;

public interface IUsersService
{
    Task<ActionResult<PagedResult<StaffUserDto>>> List(
        [FromQuery] string? q, [FromQuery] UserRole? role, [FromQuery] bool? isActive,
        [FromQuery] PageQuery page);
    Task<ActionResult<StaffUserDto>> Get(int id);
    Task<ActionResult<TempCredentialResponse>> Create(CreateStaffRequest req);
    Task<IActionResult> Update(int id, UpdateStaffRequest req);
    Task<IActionResult> SetActive(int id, [FromQuery] bool value);
    Task<ActionResult<TempCredentialResponse>> ResetPassword(int id);
    Task<IActionResult> Doctors();
}

using DiaCompanion.Api.Common;
using DiaCompanion.Api.Data;
using DiaCompanion.Api.Entities;
using DiaCompanion.Dtos;
using Microsoft.EntityFrameworkCore;
using System.Data;

namespace DiaCompanion.Api.Repositories;

/// <summary>
/// EF Core implementation. Đây là lớp duy nhất (cùng các partial của nó)
/// được phép làm việc trực tiếp với AppDbContext trong application layer.
/// </summary>
public sealed partial class EfRepository : IRepository
{
    private readonly AppDbContext _db;

    public EfRepository(AppDbContext db) => _db = db;

    public void Add<TEntity>(TEntity entity) where TEntity : class => _db.Set<TEntity>().Add(entity);

    public void AddRange<TEntity>(IEnumerable<TEntity> entities) where TEntity : class =>
        _db.Set<TEntity>().AddRange(entities);

    public void Remove<TEntity>(TEntity entity) where TEntity : class => _db.Set<TEntity>().Remove(entity);

    public void ApplyOriginalRowVersion<TEntity>(TEntity entity, string rowVersion)
        where TEntity : class
    {
        _db.Entry(entity).Property("RowVer").OriginalValue = RowVersionCodec.Decode(rowVersion);
    }

    public Task<int> CommitAsync(CancellationToken cancellationToken = default) =>
        _db.SaveChangesAsync(cancellationToken);

    public async Task<bool> TryCommitAsync(CancellationToken cancellationToken = default)
    {
        try
        {
            await _db.SaveChangesAsync(cancellationToken);
            return true;
        }
        catch (DbUpdateConcurrencyException)
        {
            return false;
        }
    }

    public Task<bool> CanConnectAsync(CancellationToken cancellationToken = default) =>
        _db.Database.CanConnectAsync(cancellationToken);

    public async Task ExecuteInTransactionAsync(
        Func<Task> action,
        IsolationLevel isolationLevel = IsolationLevel.ReadCommitted,
        CancellationToken cancellationToken = default)
    {
        var strategy = _db.Database.CreateExecutionStrategy();
        await strategy.ExecuteAsync(async () =>
        {
            await using var tx = await _db.Database.BeginTransactionAsync(isolationLevel, cancellationToken);
            try
            {
                await action();
                await tx.CommitAsync(cancellationToken);
            }
            catch
            {
                await tx.RollbackAsync(cancellationToken);
                throw;
            }
        });
    }

    public async Task<TResult> ExecuteInTransactionAsync<TResult>(
        Func<Task<TResult>> action,
        IsolationLevel isolationLevel = IsolationLevel.ReadCommitted,
        CancellationToken cancellationToken = default)
    {
        TResult? result = default;
        await ExecuteInTransactionAsync(async () =>
        {
            result = await action();
        }, isolationLevel, cancellationToken);
        return result!;
    }



    public Task<User?> GetActiveUserByIdAsync(
    int userId,
    CancellationToken ct = default)
    {
        return _db.Users
            .FirstOrDefaultAsync(
                u => u.Id == userId && u.IsActive,
                ct);
    }

    public Task<bool> UserAlreadyLinkedToActivePatientAsync(int userId, CancellationToken ct = default)
    {
        return _db.Patients.AnyAsync(
        p => p.UserId == userId && !p.IsVoided,
        ct);
    }

    public Task<bool> ActiveUserPhoneExistsExceptUserAsync(string phone, int exceptUserId, CancellationToken ct = default)
    {
        return _db.Users.AnyAsync(
        u => u.Phone == phone
             && u.IsActive
             && u.Id != exceptUserId,
        ct);
    }

    public async Task<IReadOnlyList<LinkableUserDto>>
    GetLinkableUsersForPatientAsync(
        string? keyword,
        int excludedUserId,
        CancellationToken ct = default)
    {
        // 1. Lấy User đang hoạt động.
        var query = _db.Users
            .Where(u => u.IsActive)

            // 2. Loại chính tài khoản đang đăng nhập.
            // Ví dụ lễ tân UserId = 20 thì User 20 không xuất hiện
            // trong danh sách để tự tạo Patient cho chính mình.
            .Where(u => u.Id != excludedUserId)

            // 3. Loại User đã có hồ sơ Patient đang hoạt động.
            .Where(u =>
                !_db.Patients.Any(p =>
                    p.UserId == u.Id &&
                    !p.IsVoided));

            // 4. Loại tất cả User đang có role Admin active.
            //
            // Nếu User có nhiều role:
            // Admin + Doctor
            // thì vẫn bị loại vì đang có Admin role.
           

        // 5. Search theo tên / email / phone.
        if (!string.IsNullOrWhiteSpace(keyword))
        {
            var q = keyword.Trim();

            query = query.Where(u =>
                u.FullName.Contains(q) ||
                (u.Email != null && u.Email.Contains(q)) ||
                (u.Phone != null && u.Phone.Contains(q)));
        }

        // 6. Chỉ lấy thông tin cần trả cho frontend.
        var users = await query
            .AsNoTracking()
            .OrderBy(u => u.FullName)
            .Select(u => new
            {
                u.Id,
                u.FullName,
                u.Email,
                u.Phone
            })
            .ToListAsync(ct);

        var userIds = users
            .Select(u => u.Id)
            .ToList();

        // 7. Lấy các role active của các User vừa tìm được.
        var roles = await _db.UserRoles
            .Join(
                _db.Roles,
                ur => ur.RoleId,
                r => r.Id,
                (ur, r) => new
                {
                    UserRole = ur,
                    Role = r
                })
            .Where(x =>
                userIds.Contains(x.UserRole.UserId)
                && x.UserRole.IsActive
                && x.Role.IsActive)
            .Select(x => new
            {
                x.UserRole.UserId,
                RoleName = x.Role.Name
            })
            .AsNoTracking()
            .ToListAsync(ct);

        // 8. Ghép User + Roles thành DTO.
        return users
            .Select(u => new LinkableUserDto
            {
                Id = u.Id,
                FullName = u.FullName,
                Email = u.Email,
                Phone = u.Phone,
                Roles = roles
                    .Where(r => r.UserId == u.Id)
                    .Select(r => r.RoleName)
                    .Distinct(StringComparer.OrdinalIgnoreCase)
                    .ToArray()
            })
            .ToList();
    }
}

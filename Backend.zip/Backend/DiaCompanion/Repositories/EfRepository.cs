    using DiaCompanion.Api.Common;
using DiaCompanion.Api.Data;
using DiaCompanion.Api.Entities;
using DiaCompanion.Dtos;
using DiaCompanion.Entities;
using Microsoft.EntityFrameworkCore;
using System.Data;
using static DiaCompanion.Api.Repositories.IRepository;

namespace DiaCompanion.Api.Repositories;

/// <summary>
/// EF Core implementation. Đây là lớp duy nhất (cùng các partial của nó)
/// được phép làm việc trực tiếp với AppDbContext trong application layer.
/// </summary>
public sealed partial class EfRepository : IRepository
{
    private readonly AppDbContext _db;

    public EfRepository(AppDbContext db) => _db = db;

    public void Add<TEntity>(TEntity entity) where TEntity : class => _db.Set<TEntity>().Add(entity);

    public void AddRange<TEntity>(IEnumerable<TEntity> entities) where TEntity : class =>
        _db.Set<TEntity>().AddRange(entities);

    public void Remove<TEntity>(TEntity entity) where TEntity : class => _db.Set<TEntity>().Remove(entity);

    public void ApplyOriginalRowVersion<TEntity>(TEntity entity, string rowVersion)
        where TEntity : class
    {
        _db.Entry(entity).Property("RowVer").OriginalValue = RowVersionCodec.Decode(rowVersion);
    }

    public Task<int> CommitAsync(CancellationToken cancellationToken = default) =>
        _db.SaveChangesAsync(cancellationToken);

    public async Task<bool> TryCommitAsync(CancellationToken cancellationToken = default)
    {
        try
        {
            await _db.SaveChangesAsync(cancellationToken);
            return true;
        }
        catch (DbUpdateConcurrencyException)
        {
            return false;
        }
    }

    public Task<bool> CanConnectAsync(CancellationToken cancellationToken = default) =>
        _db.Database.CanConnectAsync(cancellationToken);

    public async Task ExecuteInTransactionAsync(
        Func<Task> action,
        IsolationLevel isolationLevel = IsolationLevel.ReadCommitted,
        CancellationToken cancellationToken = default)
    {
        var strategy = _db.Database.CreateExecutionStrategy();
        await strategy.ExecuteAsync(async () =>
        {
            await using var tx = await _db.Database.BeginTransactionAsync(isolationLevel, cancellationToken);
            try
            {
                await action();
                await tx.CommitAsync(cancellationToken);
            }
            catch
            {
                await tx.RollbackAsync(cancellationToken);
                throw;
            }
        });
    }

    public async Task<TResult> ExecuteInTransactionAsync<TResult>(
        Func<Task<TResult>> action,
        IsolationLevel isolationLevel = IsolationLevel.ReadCommitted,
        CancellationToken cancellationToken = default)
    {
        TResult? result = default;
        await ExecuteInTransactionAsync(async () =>
        {
            result = await action();
        }, isolationLevel, cancellationToken);
        return result!;
    }



    public Task<User?> GetUserByIdAsync(
        int userId,
        CancellationToken ct = default)
    {
        // Users.IsActive không còn là trạng thái tài khoản.
        return _db.Users.FirstOrDefaultAsync(u => u.Id == userId, ct);
    }

    public Task<bool> UserAlreadyLinkedToActivePatientAsync(int userId, CancellationToken ct = default)
    {
        return _db.Patients.AnyAsync(
        p => p.UserId == userId && !p.IsVoided,
        ct);
    }

    public Task<bool> UserPhoneExistsExceptUserAsync(
        string phone,
        int exceptUserId,
        CancellationToken ct = default)
    {
        return _db.Users.AnyAsync(
            u => u.Phone == phone && u.Id != exceptUserId,
            ct);
    }


    private IQueryable<User> BuildLinkablePatientUsersQuery(
    int excludedUserId)
    {
        return _db.Users

            // Không cho chính User đang thao tác tự chọn mình.
            .Where(u => u.Id != excludedUserId)

            // User không được đang link với Patient active.
            //
            // _db.Patients có global query filter:
            // !IsVoided
            //
            // nên Patient đã void sẽ KHÔNG bị tính ở đây.
            .Where(u =>
                !_db.Patients.Any(p =>
                    p.UserId == u.Id))

            // Không cho Admin active đi qua luồng tạo Patient này.
            .Where(u =>
                !u.UserRoles.Any(ur =>
                    ur.Role.Name == Roles.Admin &&
                    ur.IsActive &&
                    ur.Role.IsActive))

            // Nếu User đang có Patient role active
            // thì không đưa vào danh sách link.
            //
            // Former Patient sau khi void phải có
            // Patient role IsActive = false.
            .Where(u =>
                !u.UserRoles.Any(ur =>
                    ur.Role.Name == Roles.Patient &&
                    ur.IsActive &&
                    ur.Role.IsActive))

            .Where(u =>

                // ========================================================
                // CASE 1:
                // Doctor hoặc Receptionist hiện tại.
                // ========================================================
                u.UserRoles.Any(ur =>
                    (ur.Role.Name == Roles.Doctor ||
                     ur.Role.Name == Roles.Receptionist) &&
                    ur.IsActive &&
                    ur.Role.IsActive)

                ||

                // ========================================================
                // CASE 2:
                // User từng là Patient:
                //
                // - có ít nhất 1 Patient đã void
                // - Patient role hiện đang inactive
                // ========================================================
                (
                    _db.Patients
                        .IgnoreQueryFilters()
                        .Any(p =>
                            p.UserId == u.Id &&
                            p.IsVoided)

                    &&

                    u.UserRoles.Any(ur =>
                        ur.Role.Name == Roles.Patient &&
                        !ur.IsActive &&
                        ur.Role.IsActive)
                )
            );
    }

    public async Task<IReadOnlyList<LinkableUserDto>>
    GetLinkableUsersForPatientAsync(
        string? keyword,
        int excludedUserId,
        CancellationToken ct = default)
    {
        // 1. Bắt đầu từ Users; trạng thái khóa nằm ở UserRoles, không dùng Users.IsActive.
        

        // 2. Loại chính tài khoản đang đăng nhập.
        // Ví dụ lễ tân UserId = 20 thì User 20 không xuất hiện
        // trong danh sách để tự tạo Patient cho chính mình.
        // 3. Loại User đã có hồ sơ Patient đang hoạt động.
        // 4. Admin không được dùng để tạo hồ sơ Patient qua luồng này.

var query = BuildLinkablePatientUsersQuery(excludedUserId);

        // 5. Search theo tên / email / phone.
        if (!string.IsNullOrWhiteSpace(keyword))
        {
            var q = keyword.Trim();

            query = query.Where(u =>
                u.FullName.Contains(q) ||
                (u.Email != null && u.Email.Contains(q)) ||
                (u.Phone != null && u.Phone.Contains(q)));
        }

        // 6. Chỉ lấy thông tin cần trả cho frontend.
        var users = await query
            .AsNoTracking()
            .OrderBy(u => u.FullName)
            .Select(u => new
            {
                u.Id,
                u.FullName,
                u.Email,
                u.Phone,
                IsFormerPatient =
                _db.Patients
                    .IgnoreQueryFilters()
                    .Any(p =>
                        p.UserId == u.Id &&
                        p.IsVoided)
            })
            .ToListAsync(ct);

        var userIds = users
            .Select(u => u.Id)
            .ToList();

        
        var roles = await _db.UserRoles
        .Where(ur =>
            userIds.Contains(ur.UserId) &&
            ur.IsActive &&
            ur.Role.IsActive)
        .Select(ur => new
        {
            ur.UserId,
            RoleName = ur.Role.Name
        })
        .ToListAsync(ct);

        // 8. Ghép User + Roles thành DTO.
        return users.Select(u => new LinkableUserDto
        {
            Id = u.Id,
            FullName = u.FullName,
            Email = u.Email,
            Phone = u.Phone,

            IsFormerPatient = u.IsFormerPatient,

            Roles = roles
            .Where(r => r.UserId == u.Id)
            .Select(r => r.RoleName)
            .Distinct()
            .ToArray()
        }).ToList();
    }
    public Task<bool> IsUserLinkableToPatientAsync(
    int userId,
    int excludedUserId,
    CancellationToken ct = default)
    {
        return BuildLinkablePatientUsersQuery(excludedUserId)
            .AnyAsync(u => u.Id == userId, ct);
    }

    public async Task<MedicalRecord?> GetActiveMedicalRecordByPatientIdAsync(
       int patientId,
       bool tracking = false,
       CancellationToken ct = default)
    {
        IQueryable<MedicalRecord> query = _db.MedicalRecords
            .Where(mr => mr.PatientId == patientId);

        // MedicalRecord đã có global query filter !IsVoided,
        // nên không cần viết lại mr.IsVoided == false ở đây.

        if (!tracking)
            query = query.AsNoTracking();

        return await query.FirstOrDefaultAsync(ct);
    }


    public async Task<Patient?> GetPatientByIdAsync(
        int patientId,
        bool tracking = false,
        CancellationToken ct = default)
    {
        IQueryable<Patient> query = _db.Patients
            .Where(p => p.Id == patientId);

        if (!tracking)
            query = query.AsNoTracking();

        return await query.FirstOrDefaultAsync(ct);
    }



    public async Task<PatientAdminTarget?> GetPatientAdminTargetAsync(
    int patientId,
    bool tracking,
    CancellationToken ct = default)
    {
        IQueryable<Patient> query = _db.Patients
            .Include(p => p.User)
            .Where(p => p.Id == patientId);

        if (!tracking)
            query = query.AsNoTracking();

        var patient = await query.FirstOrDefaultAsync(ct);

        if (patient is null)
            return null;


        if (patient.UserId is not int userId)
        {
            return new PatientAdminTarget(
                patient,
                null,
                null);
        }


        IQueryable<UserRole> roleQuery = _db.UserRoles
            .Where(ur =>
                ur.UserId == userId &&
                ur.Role.Name == Roles.Patient);

        if (!tracking)
            roleQuery = roleQuery.AsNoTracking();

        var patientRole =
            await roleQuery.FirstOrDefaultAsync(ct);


        return new PatientAdminTarget(
            patient,
            patient.User,
            patientRole);
    }



   

   

  
}

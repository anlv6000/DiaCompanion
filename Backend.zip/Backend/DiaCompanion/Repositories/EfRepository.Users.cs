using Microsoft.EntityFrameworkCore;
using DiaCompanion.Api.Common;
using DiaCompanion.Api.Entities;

namespace DiaCompanion.Api.Repositories;

public sealed partial class EfRepository
{
    // ============================================================
    // DANH SÁCH STAFF
    // ============================================================

    public async Task<StaffPage> GetStaffPageAsync(
        string? q,
        string? roleName,
        bool? isActive,
        PageQuery page,
        CancellationToken ct = default)
    {
        // Chỉ lấy user từng có Doctor / Receptionist.
        // Không check UserRole.IsActive để tài khoản đã khóa vẫn hiện.
        // Admin và Patient-only không xuất hiện.
        var query = _db.Users
            .AsNoTracking()
            .Where(u =>
                u.UserRoles.Any(ur =>
                    ur.Role.Name == Roles.Doctor
                    || ur.Role.Name == Roles.Receptionist))

            // Nếu User có Admin thì loại khỏi màn Staff.
            .Where(u =>
                !u.UserRoles.Any(ur =>
                    ur.Role.Name == Roles.Admin));


        // ========================================================
        // FILTER
        // ========================================================

        // Tìm theo tên / email.
        if (!string.IsNullOrWhiteSpace(q))
        {
            var term = q.Trim();

            query = query.Where(u =>
                u.FullName.Contains(term)
                || (u.Email != null && u.Email.Contains(term)));
        }

        // Filter theo Doctor / Receptionist.
        string? staffRole = null;

        if (!string.IsNullOrWhiteSpace(roleName))
        {
            var role = roleName.Trim();

            if (role.Equals(Roles.Doctor, StringComparison.OrdinalIgnoreCase))
                staffRole = Roles.Doctor;
            else if (role.Equals(Roles.Receptionist, StringComparison.OrdinalIgnoreCase))
                staffRole = Roles.Receptionist;
        }

        if (staffRole is not null)
        {
            query = query.Where(u =>
                u.UserRoles.Any(ur =>
                    ur.Role.Name == staffRole));
        }

        /*
         * Trạng thái ở màn Staff = UserRoles.IsActive.
         *
         * true:
         *      còn ít nhất một staff role active.
         *
         * false:
         *      có staff role nhưng không còn staff role nào active.
         *
         * null:
         *      lấy cả đang hoạt động + đã khóa.
         */
        if (isActive is bool active)
        {
            if (staffRole is not null)
            {
                // Nếu đang filter theo role cụ thể,
                // trạng thái áp dụng cho chính role đó.
                query = query.Where(u =>
                    u.UserRoles.Any(ur =>
                        ur.Role.Name == staffRole
                        && ur.IsActive == active));
            }
            else if (active)
            {
                query = query.Where(u =>
                    u.UserRoles.Any(ur =>
                        (ur.Role.Name == Roles.Doctor
                         || ur.Role.Name == Roles.Receptionist)
                        && ur.IsActive));
            }
            else
            {
                query = query.Where(u =>
                    !u.UserRoles.Any(ur =>
                        (ur.Role.Name == Roles.Doctor
                         || ur.Role.Name == Roles.Receptionist)
                        && ur.IsActive));
            }
        }


        // ========================================================
        // COUNT + SORT + PHÂN TRANG
        // ========================================================

        var total = await query.CountAsync(ct);

        query = page.Sort?.ToLowerInvariant() switch
        {
            "name" => page.Desc
                ? query.OrderByDescending(u => u.FullName)
                : query.OrderBy(u => u.FullName),

            "created" => page.Desc
                ? query.OrderByDescending(u => u.CreatedAt)
                : query.OrderBy(u => u.CreatedAt),

            _ => query.OrderBy(u => u.FullName)
        };

        var users = await query
            .Skip(page.Skip)
            .Take(page.PageSize)
            .ToListAsync(ct);


        // ========================================================
        // LẤY ROLE CỦA CÁC USER TRONG TRANG
        // ========================================================

        var userIds = users
            .Select(u => u.Id)
            .ToArray();

        var roleRows = await _db.UserRoles
            .AsNoTracking()
            .Where(ur =>
                userIds.Contains(ur.UserId)

                // Màn Staff chỉ lấy staff role.
                && (ur.Role.Name == Roles.Doctor
                    || ur.Role.Name == Roles.Receptionist))
            .Select(ur => new
            {
                ur.UserId,
                RoleName = ur.Role.Name,

                // Trạng thái khóa/mở role của user.
                AssignmentIsActive = ur.IsActive,

                // Trạng thái role ở cấp hệ thống.
                RoleIsActive = ur.Role.IsActive
            })
            .ToListAsync(ct);


        // ========================================================
        // GHÉP USER + ROLE
        // ========================================================

        var rolesByUser = roleRows
            .GroupBy(x => x.UserId)
            .ToDictionary(
                g => g.Key,
                g => (IReadOnlyList<StaffRoleData>)g
                    .Select(x => new StaffRoleData(
                        x.RoleName,
                        x.AssignmentIsActive,
                        x.RoleIsActive))
                    .ToList());

        var items = users
            .Select(u => new StaffUserData(
                u,
                rolesByUser.GetValueOrDefault(u.Id)
                    ?? Array.Empty<StaffRoleData>()))
            .ToList();

        return new StaffPage(items, total);
    }


    // ============================================================
    // LẤY CHI TIẾT 1 STAFF
    // ============================================================

    public async Task<StaffUserData?> GetStaffAsync(
        int id,
        bool tracking,
        CancellationToken ct = default)
    {
        /*
         * Không check UserRole.IsActive.
         *
         * Lý do:
         * staff đã bị khóa vẫn phải load được để Admin mở lại.
         *
         * Đồng thời:
         * - phải có Doctor hoặc Receptionist
         * - không được là Admin
         */

        IQueryable<User> query = _db.Users
            .Where(u =>
                u.Id == id

                && u.UserRoles.Any(ur =>
                    ur.Role.Name == Roles.Doctor
                    || ur.Role.Name == Roles.Receptionist)

                && !u.UserRoles.Any(ur =>
                    ur.Role.Name == Roles.Admin));

        if (!tracking)
            query = query.AsNoTracking();

        var user = await query.FirstOrDefaultAsync(ct);

        if (user is null)
            return null;


        // Lấy cả staff role active và inactive.
        var roles = await _db.UserRoles
            .AsNoTracking()
            .Where(ur =>
                ur.UserId == id
                && (ur.Role.Name == Roles.Doctor
                    || ur.Role.Name == Roles.Receptionist))
            .Select(ur => new StaffRoleData(
                ur.Role.Name,
                ur.IsActive,
                ur.Role.IsActive))
            .ToListAsync(ct);

        return new StaffUserData(user, roles);
    }


    // ============================================================
    // EMAIL
    // ============================================================

    public Task<bool> EmailExistsAsync(
        string email,
        int? exceptUserId = null,
        CancellationToken ct = default)
    {
        var normalized = email
            .Trim()
            .ToLowerInvariant();

        /*
         * Không dùng Users.IsActive.
         *
         * Staff bị khóa role vẫn là cùng một User và vẫn sở hữu email.
         * Không được tạo User mới trùng email.
         */
        return _db.Users.AnyAsync(
            u =>
                u.Email == normalized
                && (!exceptUserId.HasValue
                    || u.Id != exceptUserId.Value),
            ct);
    }


    // ============================================================
    // ROLE MASTER
    // ============================================================

    public async Task<IReadOnlyList<string>> GetActiveRoleNamesByNamesAsync(
        IEnumerable<string> names,
        CancellationToken ct = default)
    {
        var requested = names
            .Where(x => !string.IsNullOrWhiteSpace(x))
            .Select(x => x.Trim())
            .Distinct(StringComparer.OrdinalIgnoreCase)
            .ToArray();

        return await _db.Roles
            .AsNoTracking()
            .Where(r =>
                r.IsActive
                && requested.Contains(r.Name))
            .Select(r => r.Name)
            .ToListAsync(ct);
    }


    // ============================================================
    // ĐỔI STAFF ROLE
    // ============================================================

    public async Task SyncStaffUserRoleAsync(
        User user,
        string roleName,
        int? assignedBy,
        CancellationToken ct = default)
    {
        /*
         * Hàm này CHỈ quản lý:
         *
         * Doctor
         * Receptionist
         *
         * KHÔNG được đụng:
         *
         * Patient
         * Admin
         */

        if (roleName != Roles.Doctor
            && roleName != Roles.Receptionist)
        {
            throw new ArgumentException(
                "Role nhân viên không hợp lệ.",
                nameof(roleName));
        }


        // Role mới phải tồn tại và đang được hệ thống cho phép.
        var targetRole = await _db.Roles
            .FirstOrDefaultAsync(
                r =>
                    r.Name == roleName
                    && r.IsActive,
                ct);

        if (targetRole is null)
            throw new InvalidOperationException(
                $"Role '{roleName}' không tồn tại hoặc đã bị vô hiệu hóa.");


        // Chỉ lấy Doctor / Receptionist hiện có của User.
        var existingStaffRoles = await _db.UserRoles
            .Where(ur =>
                ur.UserId == user.Id
                && (ur.Role.Name == Roles.Doctor
                    || ur.Role.Name == Roles.Receptionist))
            .ToListAsync(ct);


        // Tắt staff role cũ khác role đang chọn.
        foreach (var assignment in existingStaffRoles)
        {
            var shouldBeActive =
                assignment.RoleId == targetRole.Id;

            if (assignment.IsActive == shouldBeActive)
                continue;

            assignment.IsActive = shouldBeActive;

            if (shouldBeActive)
            {
                assignment.AssignedAt = DateTime.UtcNow;
                assignment.AssignedBy = assignedBy;
            }
        }


        // Nếu chưa từng có role này thì tạo UserRole mới.
        var targetAssignment = existingStaffRoles
            .FirstOrDefault(x =>
                x.RoleId == targetRole.Id);

        if (targetAssignment is null)
        {
            _db.UserRoles.Add(new UserRole
            {
                UserId = user.Id,
                RoleId = targetRole.Id,
                AssignedBy = assignedBy,
                AssignedAt = DateTime.UtcNow,
                IsActive = true
            });
        }
    }


    // ============================================================
    // ĐẾM USER ACTIVE TRONG ROLE
    // ============================================================

    public Task<int> CountOtherActiveUsersInRoleAsync(
        int excludedUserId,
        string roleName,
        CancellationToken ct = default)
    {
        /*
         * Active ở đây được xác định bằng UserRole.
         *
         * Không dùng Users.IsActive làm trạng thái khóa staff.
         */
        return _db.Users.CountAsync(
            u =>
                u.Id != excludedUserId

                && u.UserRoles.Any(ur =>
                    ur.Role.Name == roleName
                    && ur.Role.IsActive
                    && ur.IsActive),
            ct);
    }


    // ============================================================
    // USER ĐANG ACTIVE TRONG ROLE
    // ============================================================

    public async Task<IReadOnlyList<User>> GetActiveUsersInRoleAsync(
        string roleName,
        CancellationToken ct = default)
    {
        return await _db.Users
            .AsNoTracking()
            .Where(u =>
                u.UserRoles.Any(ur =>
                    ur.Role.Name == roleName
                    && ur.Role.IsActive
                    && ur.IsActive))
            .OrderBy(u => u.FullName)
            .ToListAsync(ct);
    }


    public Task<bool> IsActiveUserInRoleAsync(
        int userId,
        string roleName,
        CancellationToken ct = default)
    {
        return _db.Users
            .AsNoTracking()
            .AnyAsync(
                u =>
                    u.Id == userId

                    && u.UserRoles.Any(ur =>
                        ur.Role.Name == roleName
                        && ur.Role.IsActive
                        && ur.IsActive),
                ct);
    }


    // ============================================================
    // KHÓA / MỞ STAFF ROLE
    // ============================================================

    public async Task SetStaffRolesActiveAsync(
        int userId,
        bool isActive,
        CancellationToken ct = default)
    {
        /*
         * CHỈ khóa/mở Doctor hoặc Receptionist.
         *
         * Tuyệt đối không đụng Patient.
         *
         * Ví dụ:
         *
         * Doctor  true  -> false
         * Patient true  -> true (giữ nguyên)
         */

        var assignments = await _db.UserRoles
            .Where(ur =>
                ur.UserId == userId

                && (ur.Role.Name == Roles.Doctor
                    || ur.Role.Name == Roles.Receptionist))
            .ToListAsync(ct);

        foreach (var assignment in assignments)
        {
            assignment.IsActive = isActive;
        }
    }
}